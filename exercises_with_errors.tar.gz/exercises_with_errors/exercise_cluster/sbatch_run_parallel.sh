sbatch --partition=msismall,agsmall run_parallel.sh
