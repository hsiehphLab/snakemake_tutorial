#!/usr/bin/bash -l


snakemake -s input_function.smk --jobname "{rulename}.{jobid}" --profile profile -w 300 --jobs 50 -p -k
